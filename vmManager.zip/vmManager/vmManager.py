from concurrent import futures
import sys
import os
import datetime
import time
import threading
import grpc
from itertools import izip, chain, repeat

try:
    from prettytable import PrettyTable
except ImportError:
    print "prettytable module not found, suggested installation: pip install prettytable"

from resConfig import *
libsPath = os.path.abspath(__file__ + "/../libs")
sys.path.insert(0,libsPath)

import wbxtf.WBXTFService
from WBXTFLogex import *

import generalTA_pb2
import generalTA_pb2_grpc

from resConfig import *

class VMManager:
    batch_size = 50

    def __init__(self):
       pass

    def shutDownHalf(self, *ips):

        '''
        shutDownList = list()
        for host in HOST_VM_MAPPING:
            shutDownList.extend(
                HOST_VM_MAPPING[host][:(len(HOST_VM_MAPPING[host])//2)]
            )
            print "appended: ", len(HOST_VM_MAPPING[host][:(len(HOST_VM_MAPPING[host])//2)])

        print shutDownList
        print "total vms to shut down:", len(shutDownList)
        '''
        shutDownList = HALF_VM_LIST
        self.batchProcess(shutDownList, self.shutDownVMs)


    def shutDownVMs(self, *ips):
        '''
        WARNING: this script does not have a method to start a VM that has been shut down!!!
        :param ips:
        :return:
        '''
        for ip in ips:
            WBXTFLogInfo("Shutting down %s" % ip)
            # Use round robbin to pick next TA Bot IP
            try:
                cmd = "shutdown"
                params = "/s /t 0 /f"
                res = wbxtf.WBXTFService.WBXTFExecCmd(ip, cmd, param=params)
                WBXTFLogInfo("Result received: %s" % str(res))
            except Exception as e:
                WBXTFLogInfo("Execption running WBXTFExecCmd: %s" % (str(e)))


    def restartVM(self, *ips):
        for ip in ips:
            WBXTFLogInfo("Restarting %s" % ip)
            # Use round robbin to pick next TA Bot IP
            try:
                cmd = "shutdown"
                params = "/t 0 /f /r"
                res = wbxtf.WBXTFService.WBXTFExecCmd(ip, cmd, param=params)
                WBXTFLogInfo("Result received: %s" % str(res))
            except Exception as e:
                WBXTFLogInfo("Execption running WBXTFExecCmd: %s" % (str(e)))

    def startResAgent(self, *ips):
        for ip in ips:
            WBXTFLogInfo("starting res Agent on  %s" % ip)
            # Use round robbin to pick next TA Bot IP

            try:
                cmd = "python resAgent.py 10.1.8.88"
                params = ""
                path = "D:\\PF_Tools\\resAdmin\\"
                res = wbxtf.WBXTFService.WBXTFExecCmdWithDir(ip, cmd, param=params, workDir=path)
                WBXTFLogInfo("Result received: %s\n" % str(res))
            except Exception as e:
                WBXTFLogInfo("Execption running WBXTFExecCmdwithDir: %s" % (str(e)))

    def stopResAgent(self, *ips):

        for ip in ips:
            WBXTFLogInfo("Stopping res Agent on %s" % ip)
            try:
                channel = grpc.insecure_channel("%s:11831" % ip)
                stub = generalTA_pb2_grpc.generalTAStub(channel)
                res = stub.exitMe(generalTA_pb2.exitRequest(exitDelaySec=2))
                WBXTFLogInfo("Result received: %s" % str(res))
            except grpc.RpcError:
                WBXTFLogInfo("gRPC Error, probably res agent is not running on %s" % ip)
            except Exception as e:
                print ("Exception stopping res Agent on %s: %s" % (ip, str(e)))

    def restartResAgent(self, *ips):
        for ip in ips:
            self.stopResAgent(ip)
            time.sleep(2)
            self.startResAgent(ip)

    def updateResAgent(self, *ips):

        for ip in ips:
            # Step 1: If res agent is present in the ip, delete it

            try:
                WBXTFLogInfo("Checking if resAgent is present on %s" % ip)
                resAgentDirPath="D:\\PF_Tools\\resAdmin"
                resAgentPath = resAgentDirPath + "\\resAgent.py"

                res = wbxtf.WBXTFService.WBXTFIsFileExist(ip, resAgentPath)
                if res == 1:
                    WBXTFLogInfo("resAgent.py present!")
                    # In success case, delete resAgent
                    self.stopResAgent(ip)

                    WBXTFLogInfo("Deleting resAgent")
                    time.sleep(2)
                    try:
                        res = wbxtf.WBXTFService.WBXTFDeleteDir(ip,resAgentDirPath)
                        if res == 1:
                            WBXTFLogInfo("Successfully deleted resAgent")
                        else:
                            WBXTFLogInfo("Failed to delete resAgent")
                    except Exception as e:
                        WBXTFLogInfo("Exception running WBXTFDeleteDir: %s" % str(e))
                else:
                    WBXTFLogInfo("resAgent.py not present in correct path")
            except Exception as e:
                WBXTFLogInfo("Exception running WBXTFIsFileExist: %s" % str(e))

            # Step 2: Copy the new res agent to the ip

            time.sleep(2)
            # Step 2.1: First create the required directory
            sourceDirPath = "D:\\git\\resAdmin"  # ! NOTE sourceDirPath needs to be changed when moving this code to 10.0.8.88 !
            destinationDir = "D:\\PF_Tools\\resAdmin"
            try:
                res = wbxtf.WBXTFService.WBXTFCreateDirectory(ip, destinationDir)
                if res == 1:
                    WBXTFLogInfo("Successfully created the res Agent directory")
                else:
                    WBXTFLogError("Could not create the directory %s on %s" % (destinationDir, ip))
            except Exception as e:
                WBXTFLogError("Exception creating the directory on %s: %s" % (ip, str(e)))

            #step 2.2: Now copy contents
            time.sleep(2)
            try:
                WBXTFLogInfo("Deploying resAgent on %s" % ip)


                res = wbxtf.WBXTFService.WBXTFCopyDir("localhost",sourceDirPath,ip,destinationDir)
                if res == 1:
                    WBXTFLogInfo("resAgent.py present!")
                else:
                    WBXTFLogError("Could not deploy resAgent on %s" % ip)
            except Exception as e:
                WBXTFLogInfo("Exception running WBXTFCopyDir: %s" % str(e))
            time.sleep(5)
            self.startResAgent(ip)

    def updateSparkAgent(self, *ips):
        # Step 1: Kill Spark
        self.killSpark(ips)

        #Step 2: Delete Spark
        self.delSpark(ips)

        # Step 3: Deploy Spark
        for ip in ips:
            self.deploySpark(ip)

        # Step 4: Install Spark
        self.installSpark(ips)

        # Step 5: Check is Spark installed successfully
        self.checkInstallSuccess(ips)

    def getVMReport(self, *ips):
        # Step 1: Check against ignore lists
        # <<CODE HERE>>

        # Step 2: Check what state resAgent is in
        # Stuff like what state grpc is int, if resAgent is running or not etc
        # <<CODE HERE>

        # USE the pretty table python module to dump result in logfile

        for ip in ips:
            pass
        pass

    def deployRunAgentBatFile(self, *ips):

        res = -1
        res2 = -1
        res3 = -1

        for ip in ips:
            # First check if res agent is present in the ip

            try:
                WBXTFLogInfo("Checking if resAgent is present on %s" % ip)
                resAgentPath = "D:\\PF_Tools\\resAdmin\\resAgent.py"
                res = wbxtf.WBXTFService.WBXTFIsFileExist(ip, resAgentPath)
                if res == 1:
                    WBXTFLogInfo("resAgent.py present in correct path!")
                else:
                    WBXTFLogInfo("resAgent.py not present in correct path")
            except Exception as e:
                WBXTFLogInfo("Exception running WBXTFIsFileExist: %s" % str(e))

            #next, copy the .bat file to startup folder and desktop
            if res == 1:
                #First to Desktop
                try:
                    WBXTFLogInfo("Deploying runAgent.bat to Desktop on %s" % ip)
                    sourceFilePath = "D:\\PF_Tools\\resAdmin\\runResAgent.bat"
                    destinationDir = "C:\\Users\\Administrator\\Desktop"

                    res2 = wbxtf.WBXTFService.WBXTFCopyFile("localhost",sourceFilePath,ip,destinationDir)
                    if res2 == 1:
                        WBXTFLogInfo("runResAgent.bat deployed successfully to Desktop on %s!" % ip)
                    else:
                        WBXTFLogInfo("Failed to deploy runResAgent.bat to Desktop on %s!" % ip)
                except Exception as e:
                    WBXTFLogInfo("Exception running WBXTFCopyFile: %s" % str(e))

                #Then to startup
                try:
                    WBXTFLogInfo("Deploying runAgent.bat to Desktop on %s" % ip)
                    sourceFilePath = "D:\\PF_Tools\\resAdmin\\runResAgent.bat"
                    destinationDir = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"

                    res3 = wbxtf.WBXTFService.WBXTFCopyFile("localhost",sourceFilePath,ip,destinationDir)
                    if res3 == 1:
                        WBXTFLogInfo("runResAgent.bat deployed successfully to Desktop on %s!" % ip)
                    else:
                        WBXTFLogInfo("Failed to deploy runResAgent.bat to Desktop on %s!" % ip)
                except Exception as e:
                    WBXTFLogInfo("Exception running WBXTFCopyFile: %s" % str(e))

        if res == 1 and res2 == 1 and res3 == 1:
            return True
        else:
            return False

    def killSpark(self, *ips):
        for ip in ips:
            try:
                WBXTFLogInfo("Killing spark on %s" % ip)
                res = wbxtf.WBXTFService.WBXTFKillProcessByName(ip,"CiscoSpark.exe")
                print "res for ip", ip, ":", res
            except Exception as e:
                WBXTFLogInfo("Exception running ")

    def delSpark(self, *ips):
        for ip in ips:
            try:
                WBXTFLogInfo("Removing spark from %s" % ip)
                filePath = "C:\\Users\\admin\\AppData\\Local\\Programs\\Cisco Spark"
                res = wbxtf.WBXTFService.WBXTFDeleteFile(ip, filePath)
                print "res:", res
            except Exception as e:
                WBXTFLogWarning("Exception removing spark from: %s" % str(e))

    def deploySpark(self, ip):
        # Deploy action can only be done one by one
        try:
            WBXTFLogInfo("Deploying Spark to Desktop on %s" % ip)
            sourceFilePath = "D:\\CiscoSpark.msi"
            destinationDir = "C:\\Users\\admin\\Desktop"

            res2 = wbxtf.WBXTFService.WBXTFCopyFile("localhost", sourceFilePath, ip, destinationDir)
            if res2 == 1:
                WBXTFLogInfo("CiscoSpark.msi deployed successfully to Desktop on %s!" % ip)
            else:
                WBXTFLogInfo("Failed to deploy CiscoSpark.msi to Desktop on %s!" % ip)
        except Exception as e:
            WBXTFLogInfo("Exception running WBXTFCopyFile: %s" % str(e))

    def installSpark(self, *ips):
        for ip in ips:
            try:
                WBXTFLogInfo("Installing Spark on %s" % ip)
                cmd = "CiscoSpark.msi"
                param = '/q'
                workDir = "C:\\Users\\admin\\Desktop"
                res = wbxtf.WBXTFService.WBXTFExecCmdWithDir(ip,cmd,param=param,workDir=workDir)
                if res == 1:
                    WBXTFLogInfo("Spark installation Successful!")
                else:
                    WBXTFLogError("Could not isntall Spark on %s" % ip)
            except Exception as e:
                WBXTFLogInfo("Exception running WBXTFExecCmdWithDir: %s" % str(e))

    def checkInstallSuccess(self, *ips):
        pass
    def delResAgent(self, *ips):
        for ip in ips:
            try:
                WBXTFLogInfo("Removing resAgent from %s" % ip)
                filePath = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\runResAgent.bat"
                res = wbxtf.WBXTFService.WBXTFDeleteFile(ip, filePath)
                print "res:", res
            except Exception as e:
                WBXTFLogWarning("Exception removing resAgent: %s" % str(e))

    def copyfile(self, ips, targetFile):

        failed_vms = list()
        for ip in ips:
            targetMachine = ip
            try:
                # First delete 
                res = wbxtf.WBXTFService.WBXTFDeleteFile(ip, targetFile)
                if not res:
                    failed_vms.append(ip)
                    continue

                res = wbxtf.WBXTFService.WBXTFCopyFileToFile("localhost", targetFile, ip, targetFile)
                if not res:
                    failed_vms.append(ip)

            except Exception as e:
                print "Exception ", e
        return failed_vms

    def grouper(self, ip_list):
       return [
           ip_list[s:e] for s,e in izip(
               range(0, len(ip_list)+1, self.batch_size),
               chain(
                   range(self.batch_size, len(ip_list)+1, self.batch_size),
                   repeat(len(ip_list))
               )
           )
           ]

    def batchProcess(self, ip_list, *task_list):
        total_ips = len(ip_list)
        thread_list = list()
        ip_batches = self.grouper(ip_list)

        for task in task_list:
            WBXTFLogInfo("Starting batch processing for task: %s" % str(task.__name__))
            for i,batch in enumerate(ip_batches):
                WBXTFLogInfo("Batch #%d/%d\t:%s"%(i,len(ip_batches), str(batch)))
                t = threading.Thread(target=task, args=(batch))
                thread_list.append(t)
                t.start()

            for t in thread_list:
                t.join()

            time.sleep(2)

if __name__ == "__main__":

    WBXTFLogSetLogLevel(WBXTF_INFO)
    timeStamp = datetime.datetime.fromtimestamp(time.time()).strftime("%y%m%d%H%M%S")
    logFilePath = os.path.join(os.path.split(os.path.realpath(__file__))[0], "log/VMManager_log_%s.txt" % timeStamp)
    WBXTFLogSetLogFilePath(logFilePath)

    # TEST
    vm_mgr = VMManager()
    #ip = "10.1.13.141"
    #vm_mgr.deployRunAgentBatFile(ip)


    #cgautam_ip_list = [
    #     "10.1.10.10",
    #     "10.1.10.11",
    #     "10.1.10.12",
    #     "10.1.10.13",
    #     "10.1.10.14",
    #     "10.1.10.15",
    #     "10.1.10.16",
    #     "10.1.10.17",
    #     "10.1.10.18",
    #     "10.1.10.19",
    #     "10.1.10.20",
    #     "10.1.10.21",
    #     "10.1.10.22",
    #     "10.1.10.23",
    #     "10.1.10.24",
    #     "10.1.10.25",
    #     "10.1.10.26",
    #     "10.1.10.27",
    #     "10.1.10.28",
    #     "10.1.10.29",
    #     "10.1.10.30",
    #     "10.1.10.31"
    # ]
    #vm_mgr.batchProcess(cgautam_ip_list, vm_mgr.updateResAgent)

    #for ip in cgautam_ip_list:
    #   vm_mgr.stopResAgent(ip)

    #for ip in cgautam_ip_list:
    #    vm_mgr.stopResAgent(ip)

    #vm_mgr.batchProcess(ALL_VM_LIST, vm_mgr.stopResAgent)

    #vm_mgr.shutDownHalf()

    ip_list = [
        "10.194.252.40",
        "10.194.252.12",
        "10.194.252.13",
        "10.194.252.14",
        "10.194.252.45",
        "10.194.252.105",
        "10.194.252.17",
        "10.194.252.18",
        "10.194.252.19",
        "10.194.252.20",
        "10.194.252.21",
        "10.194.252.22",
        "10.194.252.23",
        "10.194.252.24",
        "10.194.252.111",
        "10.194.252.26",
        "10.194.252.27",
        "10.194.252.28",
        "10.194.252.29",
        "10.194.252.30",
        "10.194.252.31",
        "10.194.252.32",
        "10.194.252.33",
        "10.194.252.34",
        "10.194.252.35",
        "10.194.252.36",
        "10.194.252.37",
        "10.194.252.38",
        "10.194.252.39",
        "10.194.252.62",
        "10.194.252.41",
        "10.194.252.42",
        "10.194.252.43",
        "10.194.252.44",
        "10.194.252.16",
        "10.194.252.46",
        "10.194.252.47",
        "10.194.252.48",
        "10.194.252.49",
        "10.194.252.50",
        "10.194.252.51",
        "10.194.252.52",
        "10.194.252.53",
        "10.194.252.54",
        "10.194.252.55",
        "10.194.252.56",
        "10.194.252.57",
        "10.194.252.58",
        "10.194.252.59",
        "10.194.252.60",
        "10.194.252.61",
        "10.194.252.108",
        "10.194.252.63",
        "10.194.252.110",
        "10.194.252.64",
        "10.194.252.65",
        "10.194.252.66",
        "10.194.252.67",
        "10.194.252.68",
        "10.194.252.69",
        "10.194.252.71",
        "10.194.252.72",
        "10.194.252.73",
        "10.194.252.74",
        "10.194.252.75",
        "10.194.252.76",
        "10.194.252.77",
        "10.194.252.78",
        "10.194.252.79",
        "10.194.252.80",
        "10.194.252.81",
        "10.194.252.82",
        "10.194.252.83",
        "10.194.252.84"
    ]
    targetFile = r'C:\nativeClient\webexclient_main.exe'
    targetFile2 = r'C:\nativeClient\webexclient_main.au3'

    failed_list = vm_mgr.copyfile(ip_list, targetFile)
    failed_list2 = vm_mgr.copyfile(ip_list, targetFile2)

    print failed_list
    print failed_list2



