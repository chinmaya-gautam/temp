S_OK = 0
NOERROR = 0
S_FALSE = 1

E_ERROR =       -1
E_NOTFOUND =    -2
E_TIMEOUT =     -3





